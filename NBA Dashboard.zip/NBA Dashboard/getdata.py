import pandas as pd
import requests
import json
from io import StringIO
import numpy as np


def datafr(startdate, enddate):

    csr = ""
    baseurl = f"https://api.balldontlie.io/v1/games/"
    headers = {'Authorization': "e7a4e743-bfeb-485f-94a1-264742b38419"}
    while True:
        # add the parameters to the url
        url = "{}?start_date={}&end_date={}&team_ids[]=10&team_ids[]=2&per_page=25{}".format(
            baseurl, startdate, enddate, csr)
        res = requests.request("GET", url, headers=headers)
        res.raise_for_status()
        data = res.json()

        if not data["data"]:
            break
        if 'next_cursor' in data['meta']:
            # update cursor number in parameter
            csr = f"&cursor={data['meta']['next_cursor']}"
            for row in data["data"]:
                yield row
        else:
            break


def get_df(startdate, enddate):
    # get a dataframe
    data = datafr(startdate, enddate)
    df = pd.read_json(StringIO(json.dumps(list(data))), orient='records')
    df.reset_index(drop=True, inplace=True)
    # extract the name from dictionary
    df['hteam'] = df['home_team'].apply(lambda x: x.get('full_name'))
    df['vteam'] = df['visitor_team'].apply(lambda x: x.get('full_name'))
    # create a team column
    df['team'] = np.where((df['hteam'] == 'Boston Celtics'), df['hteam'],
                          np.where((df['hteam'] == 'Golden State Warriors'),
                                   df['hteam'], df['vteam']))

    # create a score column
    df['team_score'] = np.where(
        (df['hteam'] == 'Boston Celtics'), df['home_team_score'],
        np.where((df['hteam'] == 'Golden State Warriors'),
                 df['home_team_score'], df['visitor_team_score']))

    return df
