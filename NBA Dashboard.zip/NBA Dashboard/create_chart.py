import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.ticker import FixedLocator


def line_chart(dfceltics, dfwarriors, chart_name, title):
         fig = plt.figure(figsize=(20, 8))
         dfceltics.sort_values('date', ascending=True)
         dfwarriors.sort_values('date', ascending=True)
         # generate celtics line graph
         dfceltics['date'] = pd.to_datetime(dfceltics['date'])
         plt.plot(dfceltics.index,
                  dfceltics['team_score'],
                  label='Boston Celtics')
         plt.gca().xaxis.set_major_locator(FixedLocator(dfceltics.index))
         plt.xticks(dfceltics.index, dfceltics["date"].dt.strftime("%m.%d.%Y"))
         # generate warriors line graph
         plt.plot(dfwarriors.index,
                  dfwarriors['team_score'],
                  label='Golden State Warriors')
         plt.gca().xaxis.set_major_locator(FixedLocator(dfwarriors.index))
         plt.xticks(dfwarriors.index,
                    dfwarriors["date"].dt.strftime("%m.%d.%Y"))
         plt.gcf().autofmt_xdate()

         plt.xticks(rotation=90)
         plt.legend()
         plt.ylabel('Score')
         plt.xlabel('Date')
         plt.title(title)
         plt.savefig(f'static/images/{chart_name}')
