from flask import Flask, render_template
import requests
from getdata import get_df
from create_chart import line_chart

app = Flask('app')


@app.route('/')
def showdashboard():

  return render_template("index.html")


@app.route("/line_chart")
def scores():
  # Get 2023 data from the API
  df = get_df('2023-01-01', '2023-12-31')
  # Get subset of data for the team
  df_celtics = df.loc[df['team'] == 'Boston Celtics', ['team_score', 'date']]

  df_warriors = df.loc[df['team'] == 'Golden State Warriors',
                       ['team_score', 'date']]
  # Generate chart
  line_chart(df_celtics, df_warriors, 'Chart1', '')
  # Get data 2022 from the API
  df = get_df('2022-01-01', '2022-12-31')
  # Get subset of data for the team
  df_celtics = df.loc[df['team'] == 'Boston Celtics', ['team_score', 'date']]
  df_warriors = df.loc[df['team'] == 'Golden State Warriors',
                       ['team_score', 'date']]
  # Generate chart
  line_chart(df_celtics, df_warriors, 'Chart2', '')
  return render_template("index.html")


@app.route("/avg_scores22")
def avg_scores22():
  #Get average score for each team 2022
  # get data
  df = get_df('2022-01-01', '2022-12-31')
  # create subset
  df_celtics = df.loc[df['team'] == 'Boston Celtics', ['team_score']]
  average1 = round(df_celtics['team_score'].mean(), 2)
  title1 = "Boston Celtics' 2022 Average Score was"
  # create subset
  df_warriors = df.loc[df['team'] == 'Golden State Warriors', ['team_score']]

  average2 = round(df_warriors['team_score'].mean(), 2)
  title2 = "Golden State Warriors' 2022 Average Score was"

  average2 = round(df_warriors['team_score'].mean(), 2)
  return render_template("index.html",
                         average1=average1,
                         average2=average2,
                         title1=title1,
                         title2=title2)


@app.route("/avg_scores23")
def avg_scores23():
  #Get average score for each team 2023
  # get data
  df = get_df('2023-01-01', '2023-12-31')
  # create subset
  df_celtics = df.loc[df['team'] == 'Boston Celtics', ['team_score']]
  average1 = round(df_celtics['team_score'].mean(), 2)
  title1 = "Boston Celtics' 2023 Average Score was"
  # create subset
  df_warriors = df.loc[df['team'] == 'Golden State Warriors', ['team_score']]
  average2 = df_warriors['team_score'].mean
  title2 = "Golden State Warriors' 2023 Average Score was"

  average2 = round(df_warriors['team_score'].mean(), 2)
  return render_template("index.html",
                         average1=average1,
                         average2=average2,
                         title1=title1,
                         title2=title2)


@app.route("/min_max")
def min_max():
  #Get average score for each team 2023
  # get data
  df = get_df('2022-01-01', '2023-12-31')
  # create subset
  df_celtics = df.loc[df['team'] == 'Boston Celtics', ['team_score']]
  min_celt = df_celtics['team_score'].min()
  max_celt = df_celtics['team_score'].max()
  desc_celt1 = f"Boston Celtics mininum score for 2022 -2023 was { min_celt}"
  desc_celt2 = f"Boston Celtics maximum score for 2022 -2023 was { max_celt}"
  # create subset
  df_warriors = df.loc[df['team'] == 'Golden State Warriors', ['team_score']]
  min_war = df_warriors['team_score'].min()
  max_war = df_warriors['team_score'].max()
  desc_war1 = f"Golden State Warriors mininum score for 2022 -2023 was {min_war}"
  desc_war2 = f"Boston Celtics maximum score for 2022 -2023 was {max_war}"

  return render_template("index.html",
                         desc_celt1=desc_celt1,
                         desc_celt2=desc_celt2,
                         desc_war1=desc_war1,
                         desc_war2=desc_war2)


app.run(host='0.0.0.0', port=8080)
