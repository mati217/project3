from flask import Flask, render_template
import nasdaqdatalink as nd
from datetime import datetime
import pandas as pd
import urllib.request
import json
from pandas.core.apply import include_axis
import pygal


def create_chart(chart_name, code_name, chart_title):

  nd.ApiConfig.api_key = "Fn9swwMjup-SUWpQcFfx"
  data = nd.get_table("QDL/BCHAIN", code=code_name)

  list1 = []

  for index, row in data.iterrows():
    #Convert the timestamp to the date format as %Y-%m-%d
    date = row[1].strftime('%Y-%m-%d')
    # convert to date
    date2 = datetime.strptime(date, '%Y-%m-%d').date()
    # get only Jan 2016 dates
    start = datetime.strptime('2016-01-01', '%Y-%m-%d').date()
    end = datetime.strptime('2016-01-31', '%Y-%m-%d').date()
    if date2 >= start and date2 <= end:
      # append to the list
      list1.append((date, row[2]))
      print(list1)
      # Extract seperate lists for date and value
      dates, value = zip(*list1)

  #Create a line chart using pygal
  chart = pygal.Line(x_label_rotation=45)
  chart.title = chart_title
  chart.x_labels = dates
  chart.add('Values', value)

  chart.render_to_file('static/images/' + chart_name + '.svg')
  return


app = Flask('app')


@app.route('/')
def btc_dashboard():

  #Get bitcoin price from API
  request = urllib.request.urlopen(
      "https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@latest/v1/currencies/btc.json"
  )
  result = json.loads(request.read())
  #save to variable
  btc_price = r"${:,.2f}".format(result["btc"]["usd"])

  create_chart(
      'TVTVR_Line', 'TVTVR',
      'January 2016 Bitcoin Trade Volume vs Transaction Volume Ratio')

  create_chart('NETDF_Line', 'NETDF', 'January 2016 Bitcoin Network Deficit')
  TVTVR_plot = 'static/images/TVTVR_Line.svg'

  NETDF_plot = 'static/images/NETDF_Line.svg'

  return render_template("index.html",
                         btc_price=btc_price,
                         TVTVR_plot=TVTVR_plot,
                         NETDF_plot=NETDF_plot)


app.run(host='0.0.0.0', port=8080)
